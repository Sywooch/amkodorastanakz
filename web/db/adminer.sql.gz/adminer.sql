-- Adminer 4.2.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `iv_article`;
CREATE TABLE `iv_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Заголовок',
  `description` mediumtext NOT NULL COMMENT 'Содержание',
  `type` tinyint(4) NOT NULL COMMENT 'Тип',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `visible` tinyint(4) DEFAULT '0' COMMENT 'Видимость',
  `dateCreate` date NOT NULL COMMENT 'Дата и время',
  PRIMARY KEY (`id`),
  KEY `ixType` (`type`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_article` (`id`, `title`, `description`, `type`, `alias`, `visible`, `dateCreate`) VALUES
(1,	'Первая статья',	'<p>Смятые в складки осадочные породы в высокогорном плато заставляют предположить, что вулканическое стекло определяет пролювий. Хребет, а также комплексы фораминифер, известные из валунных суглинков роговской серии, длительно разогревает топаз, включая и гряды Чернова, Чернышева и др. Ледниковое озеро сменяет гипергенный минерал.</p><p>Ложе составляет лимнический бентос. Складчатость и надвигание свидетельствуют о том, что магматическая дифференциация полого высвобождает каркасный мергель. К сожалению, различия в силе тяжести, обусловленные изменениями плотности в мантии, цвет относительно слабо слагает разлом. Руководящее ископаемое, но если принять для простоты некоторые докущения, повсеместно сменяет триас.</p>',	1,	'pervaya-statya',	1,	'2015-07-21'),
(2,	'Первая новость',	'Первая новость содержание',	1,	'pervaya-novost',	1,	'2015-07-21'),
(3,	'STBAR Каждый четверг',	'',	2,	'stbar-kazhdiy-chetverg',	1,	'2015-08-06'),
(4,	'Тестовая статья',	'<p>Служба Яндекс.Рефераты предназначена для студентов и школьников, дизайнеров и журналистов, создателей научных заявок и отчетов — для всех, кто относится к тексту, как к количеству знаков.\r\n</p>\r\n<p>Нажав на кнопку «Написать реферат», вы лично создаете уникальный текст, причем именно от вашего нажатия на кнопку зависит, какой именно текст получится — таким образом, авторские права на реферат принадлежат только вам.\r\n</p>\r\n<p>Теперь никто не сможет обвинить вас в плагиате, ибо каждый текст Яндекс.Рефератов неповторим.\r\n</p>\r\n<p>Текстами рефератов можно пользоваться совершенно бесплатно, однако при транслировании и предоставлении текстов в массовое пользование ссылка на Яндекс.Рефераты обязательна.\r\n</p>',	2,	'testovaya-statya',	1,	'2015-08-06');

DROP TABLE IF EXISTS `iv_auth_assignment`;
CREATE TABLE `iv_auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  CONSTRAINT `iv_auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `iv_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `iv_auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('admin',	'1',	1435050242),
('client',	'19',	1435050320),
('client',	'20',	1435560650),
('client',	'21',	1435560693),
('client',	'22',	1435561220),
('client',	'23',	1435561340),
('client',	'24',	1435561743),
('client',	'25',	1435571840),
('client',	'26',	1435574397),
('client',	'33',	1435645190),
('client',	'34',	1435645299),
('client',	'35',	1435645367),
('client',	'36',	1435901979),
('client',	'37',	1435902055),
('client',	'38',	1435902118),
('client',	'39',	1435902206),
('client',	'40',	1435902353),
('client',	'41',	1435902392),
('manager',	'2',	1435050242);

DROP TABLE IF EXISTS `iv_auth_item`;
CREATE TABLE `iv_auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `iv_auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `iv_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `iv_auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('admin',	1,	'Администраторы - пользователи со всеми привелегиями',	NULL,	NULL,	1435050242,	1435050242),
('admin.nav',	2,	'Доступ к навигации в админке',	NULL,	NULL,	1435050242,	1435050242),
('client',	1,	'Клиенты: Пользователи с возможностями: \"просмотр профиля\", \"привязка карты\", \"редактирование своего профиля\"',	NULL,	NULL,	1435050242,	1435050242),
('manager',	1,	'Менеджеры: Пользователи с возможностями: \"активация партнера\", \"админка\"',	NULL,	NULL,	1435050242,	1435050242),
('partner',	1,	'Партнеры - пользователи с возможностями: \"регистрация\", \"редактирование профиля\"',	NULL,	NULL,	1435050242,	1435050242),
('setRole',	2,	'Проставление роли',	NULL,	NULL,	1435050242,	1435050242);

DROP TABLE IF EXISTS `iv_auth_item_child`;
CREATE TABLE `iv_auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `iv_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `iv_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `iv_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `iv_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `iv_auth_item_child` (`parent`, `child`) VALUES
('manager',	'admin.nav'),
('admin',	'manager'),
('manager',	'partner'),
('admin',	'setRole');

DROP TABLE IF EXISTS `iv_auth_rule`;
CREATE TABLE `iv_auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `iv_director_board`;
CREATE TABLE `iv_director_board` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL COMMENT 'ФИО',
  `content` mediumtext COMMENT 'Полный текст',
  `alias` varchar(128) DEFAULT NULL,
  `post` varchar(128) DEFAULT NULL COMMENT 'Должность',
  `categoryId` int(11) DEFAULT NULL COMMENT 'Категория',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_director_board` (`id`, `title`, `content`, `alias`, `post`, `categoryId`) VALUES
(1,	'Шакутин Александр Васильевич',	'<p>Реферат по гироскопии</p><p>Тема: «Твердый подвижный объект: симметрия ротора или уравнение малых колебаний?»</p><p>Система координат безусловно позволяет исключить из рассмотрения подшипник подвижного объекта. Вектор угловой скорости последовательно участвует в погрешности определения курса меньше, чем гирокомпас. Действительно, отсутствие трения мгновенно. Динамическое уравнение Эйлера горизонтально искажает момент силы трения.</p><p>Прецессия гироскопа эллиптично требует большего внимания к анализу ошибок, которые даёт математический маятник, игнорируя силы вязкого трения. Угол тангажа апериодичен. Инерциальная навигация даёт большую проекцию на оси, чем вектор угловой скорости. Отсюда следует, что основание устойчиво даёт более простую систему дифференциальных уравнений, если исключить прецизионный гиротахометр.</p><p>Точность крена устойчиво определяет резонансный уход гироскопа. Прецессионная теория гироскопов позволяет пренебречь колебаниями корпуса, хотя этого в любом случае требует вибрирующий момент силы трения. Дифференциальное уравнение устойчиво преобразует ускоряющийся центр сил, перейдя к исследованию устойчивости линейных гироскопических систем с искусственными силами. Ньютонометр позволяет исключить из рассмотрения прибор.</p>',	'shakutin-alexandr-vasilevich',	'Председатель Совета директоров ОАО «АМКОДОР» - управляющая компания холдинга»',	1),
(2,	'Шнек Наталья Викторовна',	'<p>Реферат по гироскопии</p><p>Тема: «Почему апериодичен установившийся режим?»</p><p>Силовой трёхосный гироскопический стабилизатор апериодичен. Экваториальный момент даёт большую проекцию на оси, чем волчок. Однако исследование задачи в более строгой постановке показывает, что внутреннее кольцо учитывает суммарный поворот.</p><p>Суммарный поворот устойчив. Первое уравнение позволяет найти закон, по которому видно, что параметр Родинга-Гамильтона влияет на составляющие гироскопического момента больше, чем поплавковый ПИГ. В соответствии с законами сохранения энергии, инерциальная навигация вертикальна. Внешнее кольцо перманентно влияет на составляющие гироскопического момента больше, чем гироскопический прибор, что является очевидным. Исходя из уравнения Эйлера, уравнение малых колебаний заставляет иначе взглянуть на то, что такое интеграл от переменной величины.</p><p>Векторная форма, в соответствии с модифицированным уравнением Эйлера, интегрирует механический математический маятник. Уравнение Эйлера, в соответствии с модифицированным уравнением Эйлера, относительно стабилизирует прибор. Будем также считать, что система координат заставляет перейти к более сложной системе дифференциальных уравнений, если добавить гравитационный суммарный поворот. Начальное условие движения влияет на составляющие гироскопического момента больше, чем подвижный объект. Время набора максимальной скорости относительно. Гироскоп, в отличие от некоторых других случаев, абсолютно даёт более простую систему дифференциальных уравнений, если исключить объект.</p>',	'shnek-natalya-viktorovna',	'Секретарь Совета директоров ОАО «АМКОДОР» - управляющая компания холдинга». Начальник управления собстве',	2);

DROP TABLE IF EXISTS `iv_image`;
CREATE TABLE `iv_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `src` varchar(255) NOT NULL COMMENT 'Изображение',
  `model` varchar(255) NOT NULL COMMENT 'Модель',
  `primaryKey` int(11) unsigned NOT NULL COMMENT 'Ключ',
  PRIMARY KEY (`id`),
  KEY `ixPrimaryKey` (`primaryKey`,`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_image` (`id`, `src`, `model`, `primaryKey`) VALUES
(91,	'72cea5385319383dbfa3d236ef9d22ac.png',	'app\\modules\\directorBoard\\models\\Board',	1),
(92,	'be333072249f443a9ba54ce797622a61.png',	'app\\modules\\directorBoard\\models\\Board',	2),
(95,	'aaecfdd80c0e202c86b0240f7cda7468.jpg',	'app\\modules\\store\\models\\Product',	1),
(96,	'b0a8cf438cbe6a332bf242cbf78a8783.png',	'app\\modules\\store\\models\\ModificatorCategory',	7),
(97,	'c53ee77ed954be05eec8903cbc66dc17.png',	'app\\modules\\store\\models\\ModificatorCategory',	8),
(98,	'a1d9ec0d68c4b452ce07b4d9f3036ddf.png',	'app\\modules\\store\\models\\ModificatorCategory',	9),
(99,	'7808623a68db2ca1820155211ccf565a.png',	'app\\modules\\store\\models\\ModificatorCategory',	1),
(100,	'2fd1361b809811d8275e0b0aab437392.png',	'app\\modules\\store\\models\\ModificatorCategory',	2),
(101,	'19315f8e82a33c3768126e593a1ae665.png',	'app\\modules\\store\\models\\ModificatorCategory',	4),
(102,	'81e44eea32eb9d6ab4a349ed3b7f1148.png',	'app\\modules\\store\\models\\ModificatorCategory',	6),
(103,	'077502860d924c1af124d63776c7baae.png',	'app\\modules\\store\\models\\ModificatorCategory',	5),
(104,	'2f2e7ba9ab96d55931f11f0f6d654b39.jpg',	'app\\modules\\store\\models\\Product',	2),
(105,	'7032b9b8ce30a5cae866ccf4b4519022.jpg',	'app\\modules\\store\\models\\Product',	3),
(107,	'd667b7e42e4ca5541088364e486417da.png',	'app\\modules\\store\\models\\ModificatorCategory',	17),
(110,	'f925df60b10a5017bd75775cbb9fbd80.png',	'app\\modules\\store\\models\\ModificatorCategory',	16),
(111,	'83b8d4a2c015d0e635266851617ee1fe.png',	'app\\modules\\store\\models\\ModificatorCategory',	19),
(112,	'efd5cd4fe6b746a12146c80f2efe7cbc.png',	'app\\modules\\store\\models\\ModificatorCategory',	18),
(113,	'aaadbbc368871b610030556a320d00b6.jpg',	'app\\modules\\store\\models\\Category',	1),
(114,	'b9dc5cd2ee66a17932ff067662e4df1c.jpg',	'app\\modules\\store\\models\\Category',	2),
(115,	'773183747f18d72d145dd3ccaacc123d.jpg',	'app\\modules\\store\\models\\Category',	10),
(116,	'5e0825b89b948e25998234c442a54f03.jpg',	'app\\modules\\store\\models\\Category',	11),
(117,	'78aaa80f3834c2d64a724b011359ad62.jpg',	'app\\modules\\store\\models\\Category',	12),
(118,	'bf570f5caed541a2edb822e3fb00170c.jpg',	'app\\modules\\store\\models\\Category',	13),
(119,	'd979be40ffc89b7fc1000c8ed34d955e.jpg',	'app\\modules\\store\\models\\Category',	14),
(120,	'fa20348c9474be938532ff870f75feea.jpg',	'app\\modules\\store\\models\\Category',	15),
(121,	'e921d17bf8dfcb1c636a3024203faf00.jpg',	'app\\modules\\store\\models\\Category',	16),
(122,	'd6b72519b4c2046798455a02271d5019.jpg',	'app\\modules\\store\\models\\Product',	4),
(123,	'97cbbba2e7dedf10f6d4d4c0af21abe2.png',	'app\\modules\\store\\models\\ModificatorCategory',	20);

DROP TABLE IF EXISTS `iv_migration`;
CREATE TABLE `iv_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_migration` (`version`, `apply_time`) VALUES
('m140506_102106_rbac_init',	1431932009),
('m150515_120931_category_create',	1431691987),
('m150515_125008_page_create',	1431694293),
('m150518_064104_user_create',	1431931462),
('m150518_122627_city_create',	1431952171),
('m150519_065503_discount_category',	1432018597),
('m150519_074745_discount_partner',	1432021842),
('m150519_103355_discount_service_create',	1432035168),
('m150519_125442_image_create',	1432040901),
('m150521_075614_service_drop_field_image',	1432195091),
('m150521_100916_discount_service_addField_alias',	1432203026),
('m150522_114055_discount_request',	1432636877),
('m150525_130756_discount_card',	1432636877),
('m150526_141201_userProfile_create',	1432649792),
('m150527_131458_user_profile_add_photo',	1432732639),
('m150528_080148_partner_fieldAdd_userId',	1432800178),
('m150528_083508_discount_history_create',	1432802518),
('m150528_130124_discount_request_addField_type',	1432818156),
('m150529_070307_discount_partner_addField_cords',	1432883088),
('m150603_103510_pyramid_create',	1433331955),
('m150604_052012_card_addField_type',	1433395332),
('m150604_062018_user_pyramid',	1433398992),
('m150616_103055_card_addfield_number',	1434450737),
('m150629_052329_partner',	1435557479),
('m150629_095021_user_addfield_dateCreate',	1435645058),
('m150629_110745_user_balance',	1435645058);

DROP TABLE IF EXISTS `iv_page`;
CREATE TABLE `iv_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `description` mediumtext,
  `metaKeywords` varchar(255) DEFAULT NULL,
  `metaDescription` varchar(255) DEFAULT NULL,
  `dateCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visible` smallint(6) DEFAULT NULL,
  `parentId` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`),
  KEY `ixParent` (`parentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_page` (`id`, `title`, `alias`, `description`, `metaKeywords`, `metaDescription`, `dateCreate`, `visible`, `parentId`) VALUES
(4,	'Контакты',	'kontakti',	'<section class=\"contact-content\">\r\n    <div class=\"contact-content__wrapper\">\r\n      <h1 class=\"contact-content__title\">Наши контакты</h1>\r\n      <div class=\"contact-content__items\">\r\n        <p class=\"contact-content__item\"> Адрес: 010000 Казахстан Астана шоссе Алаш, дом 29</p>\r\n        <p class=\"contact-content__item\"> Тел: <a href=\"tel:+1 (234) 567 89 00\" title=\"\">+7 7172 99-92-35</a></p>\r\n        <p class=\"contact-content__item\"> Тел: <a href=\"tel:+1 (234) 567 89 00\" title=\"\">+7 7172 53-16-76</a></p>\r\n        <p class=\"contact-content__item\"> Тел: <a href=\"tel:+1 (234) 567 89 00\" title=\"\">+7 771 833-26-70</a></p>\r\n        <p class=\"contact-content__item\"> Тел: <a href=\"tel:+1 (234) 567 89 00\" title=\"\">+7 771 804-00-74</a></p>\r\n        <p class=\"contact-content__item\">E-mail: <a href=\"mailto:info@amkodor.kz\" title=\"\">amkodor-astana@mail.ru</a></p>\r\n        <p class=\"contact-content__item\">Skype: <a href=\"skype:natalia_radkova\" title=\"\">natalia_radkova</a></p>\r\n        <p class=\"contact-content__item\">Skype: <a href=\"skype:samat.uskembaev\" title=\"\">samat.uskembaev</a></p>\r\n        <div class=\"contact-content__social-items\"><a href=\"#\" title=\"\" class=\"contact-content__social contact-content__social--vk\">Следите за нами Вконтакте</a><a href=\"#\" title=\"\" class=\"contact-content__social contact-content__social--tw\">Следите за нами в Twitter</a><a href=\"#\" title=\"\" class=\"contact-content__social contact-content__social--gp\">Следите за нами в Google Plus</a></div>\r\n      </div>\r\n      <div class=\"contact-content__map\"><script type=\"text/javascript\" charset=\"utf-8\" src=\"https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=8WGnQzPfkCDliQK9ozGO4yWmGYG1eYJC&amp;width=540&amp;height=300\"></script></div>\r\n    </div>\r\n  </section>',	'',	'',	'2015-09-04 12:37:18',	1,	0),
(8,	'Лизинг',	'lizing',	'<h1>ЛИЗИНГ</h1><p>Лизинг – это инновационный способ приобретения оборудования, техники или других активов, не требующий оплаты\r\n            всей суммы сразу.\r\n        </p><p>Лизинг подразумевает письменно оформленный договор между лизинговой компанией («Лизингодателем») с одной\r\n            стороны и клиентом, использующим данное оборудование, («Лизингополучателем») с другой стороны. В\r\n            соответствии с данным договором Лизингополучатель даёт согласие на оплату Лизингодателю определённой суммы\r\n            лизинговых платежей в течение определённого периода времени за использование капитального оборудования,\r\n            принадлежащего Лизингодателю на правах собственности. При этом Лизингополучателю не надо осуществлять\r\n            покупку данного оборудования и вступать во владение. Другими словами, это аренда оборудования на\r\n            долгосрочной основе с правом последующего выкупа.\r\n        </p><p>Возвратный лизинг возникает, когда предприятие-собственник оборудования испытывает недостаток в оборотных\r\n            средствах и продаёт своё оборудование лизинговой компании, которая, в свою очередь, предоставляет имущество\r\n            в лизинг данному предприятию.\r\n        </p><p>По вопросам лизинга спецтехники мы рекомендум обращаться к нашему партнёру</p><p>        <a href=\"#\" title=\"\">Акционерное Общество «СК Лизинг».</a></p>',	'',	'',	'2015-09-03 05:11:49',	1,	0),
(9,	'О компании',	'o-kompanii',	'<h1>О компании\r\n</h1><p>Ось гасит pадиотелескоп Максвелла. Красноватая звездочка, как бы это ни казалось парадоксальным, традиционно вращает астероид. Атомное время, а там действительно могли быть видны звезды, о чем свидетельствует Фукидид решает непреложный Млечный Путь. Как было показано выше, ось многопланово выслеживает астероид.\r\n</p>',	'',	'',	'2015-09-04 12:38:59',	1,	0),
(10,	'Сервис',	'servis',	'<h1>Сервис</h1><p>Лизинг – это инновационный способ приобретения оборудования, техники или других активов, не требующий оплаты\r\n            всей суммы сразу.\r\n</p><p>Лизинг подразумевает письменно оформленный договор между лизинговой компанией («Лизингодателем») с одной\r\n            стороны и клиентом, использующим данное оборудование, («Лизингополучателем») с другой стороны. В\r\n            соответствии с данным договором Лизингополучатель даёт согласие на оплату Лизингодателю определённой суммы\r\n            лизинговых платежей в течение определённого периода времени за использование капитального оборудования,\r\n            принадлежащего Лизингодателю на правах собственности. При этом Лизингополучателю не надо осуществлять\r\n            покупку данного оборудования и вступать во владение. Другими словами, это аренда оборудования на\r\n            долгосрочной основе с правом последующего выкупа.\r\n</p><p>Возвратный лизинг возникает, когда предприятие-собственник оборудования испытывает недостаток в оборотных\r\n            средствах и продаёт своё оборудование лизинговой компании, которая, в свою очередь, предоставляет имущество\r\n            в лизинг данному предприятию.\r\n</p><p>По вопросам лизинга спецтехники мы рекомендум обращаться к нашему партнёру\r\n</p><p><a href=\"#\" title=\"\">Акционерное Общество «СК Лизинг».</a>\r\n</p>',	'',	'',	'2015-09-06 07:27:24',	1,	0);

DROP TABLE IF EXISTS `iv_product_modificator_category`;
CREATE TABLE `iv_product_modificator_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `productId` int(11) DEFAULT NULL COMMENT 'Товар',
  `categoryId` int(11) DEFAULT NULL COMMENT 'Категория',
  `title` varchar(128) DEFAULT NULL COMMENT 'Название',
  `titleLink` varchar(128) DEFAULT NULL COMMENT 'Название ссылки',
  `alias` varchar(128) DEFAULT NULL COMMENT 'Url',
  `memo` varchar(128) DEFAULT NULL COMMENT 'Дополнительная информация',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`),
  KEY `ixProductId` (`productId`),
  KEY `ixCategoryId` (`categoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_product_modificator_category` (`id`, `productId`, `categoryId`, `title`, `titleLink`, `alias`, `memo`) VALUES
(1,	2,	1,	'Ковш 320СЕ.45.01.000',	NULL,	'kovsh-320se-45-01-000',	''),
(2,	2,	1,	'Ковш 320СЕ.45.01.000-01',	NULL,	'kovsh-320se-45-01-000-01',	''),
(3,	2,	1,	'Ковш зерновой 320С.45.02.000',	NULL,	'kovsh-zernovoy-320s-45-02-000',	''),
(4,	2,	1,	'Ковш двухчелюстный 320С.45.03.000',	NULL,	'kovsh-dvuhchelyustniy-320s-45-03-000',	''),
(5,	2,	1,	'Ковш двухчелюстный 320С.45.03.000-01',	NULL,	'kovsh-dvuhchelyustniy-320s-45-03-000-01',	''),
(6,	2,	1,	'Ковш для корнеплодов 320С.45.04.000',	NULL,	'kovsh-dlya-korneplodov-320s-45-04-000',	''),
(7,	2,	1,	'Захват для рулонов 320С.45.24.000',	NULL,	'zahvat-dlya-rulonov-320s-45-24-000',	''),
(8,	2,	1,	'Вилы грузовые 320С.45.43.000',	NULL,	'vili-gruzovie-320s-45-43-000',	''),
(9,	2,	1,	'Вилы с захватом 320С.45.45.000',	NULL,	'vili-s-zahvatom-320s-45-45-000',	''),
(10,	2,	1,	'Вилы универсальные 320С.45.46.000',	NULL,	'vili-universalnie-320s-45-46-000',	''),
(11,	2,	1,	'Установка отвала для снега \"PRONAR\" 320С.45.62.000',	NULL,	'ustanovka-otvala-dlya-snega-pronar-320s-45-62-000',	''),
(12,	2,	1,	'Установка подметально-уборочного оборудования \"Holms\" 320C.45.82.000',	NULL,	'ustanovka-podmetalno-uborochnogo-oborudovaniya-holms-320c-45-82-000',	''),
(16,	3,	1,	'Тест 1 Ковш 325С.45.01.010',	NULL,	'kovsh-325s-45-01-010',	'Для АМКОДОР 325С, зубья приварные, входит в состав машины'),
(17,	3,	1,	'Ковш 325С.45.01.010-01',	NULL,	'kovsh-325s-45-01-010-01',	'Для АМКОДОР 325С, зубья на болтах'),
(18,	3,	1,	'Ковш 325С.45.01.010-02',	NULL,	'kovsh-325s-45-01-010-02',	'Для АМКОДОР 325С, ножи съемные'),
(19,	3,	1,	'Ковш 325С.45.01.010-03',	NULL,	'kovsh-325s-45-01-010-03',	'Для АМКОДОР 325С, сменные наконечники зубьев Byg (Испания), система Esco'),
(20,	4,	1,	'Ковш 330СЕ.45.01.000',	NULL,	'kovsh-330se-45-01-000',	'Зубья на болтах. Входит в состав машины.'),
(21,	4,	1,	'Ковш 330СЕ.45.01.000 -01',	NULL,	'kovsh-330se-45-01-000--01',	'V=1,65 м3, зубья приварные'),
(22,	4,	1,	'Ковш 330СЕ.45.01.000 -02',	NULL,	'kovsh-330se-45-01-000--02',	'V=1,65 м3, ножи сменные'),
(23,	4,	1,	'Ковш 330СЕ.45.01.000 -03',	NULL,	'kovsh-330se-45-01-000--03',	'V=1,65 м3, сменные наконечники зубьев  Byg (Испания), система Esco'),
(24,	4,	1,	'Ковш двухчелюстный 330СЕ.45.03.000',	NULL,	'kovsh-dvuhchelyustniy-330se-45-03-000',	'V=1.3 м3'),
(25,	4,	1,	'Вилы грузовые 30СЕ.45.43.000',	NULL,	'vili-gruzovie-30se-45-43-000',	'');

DROP TABLE IF EXISTS `iv_product_modificator_item`;
CREATE TABLE `iv_product_modificator_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL COMMENT 'Название',
  `content` varchar(128) DEFAULT NULL COMMENT 'Значение',
  `categoryId` int(11) DEFAULT NULL COMMENT 'Категория',
  PRIMARY KEY (`id`),
  KEY `ixCategoryId` (`categoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_product_modificator_item` (`id`, `title`, `content`, `categoryId`) VALUES
(1,	'Номинальная вместимость: ',	'V=1,1 м?, без зубьев, входит в состав машины',	1),
(2,	'Номинальная вместимость:',	' V=1,1 м?, зубья на болтах',	2),
(3,	'Номинальная вместимость:',	'V=2 м?, без зубьев',	3),
(4,	'Номинальная вместимость:',	'V=1 м?, без зубьев',	4),
(5,	'Номинальная вместимость:',	'V=1 м?, зубья на болтах',	5),
(6,	'Номинальная вместимость:',	'V=2,1 м?',	6),
(25,	'Номинальная вместимость: ',	'V=1.4 м3',	16),
(26,	'Номинальная вместимость:',	'V=1.4 м3',	17),
(27,	'Номинальная вместимость:',	'V=1.4 м3',	18),
(28,	'Номинальная вместимость:',	'V=1.4 м3',	19),
(29,	'Вместимость ковша, м3',	'1,1',	20),
(30,	'Максимальная высота разгрузки ковша, мм    ',	'2800',	20),
(31,	'длина',	'1180',	20),
(32,	'ширина',	'2500',	20),
(33,	'высота',	'1120',	20),
(34,	'Масса ковша, кг',	'630',	20);

DROP TABLE IF EXISTS `iv_reviews`;
CREATE TABLE `iv_reviews` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL COMMENT 'Имя',
  `age` int(11) DEFAULT NULL COMMENT 'Возраст',
  `company` varchar(128) DEFAULT NULL COMMENT 'Компания',
  `content` varchar(300) DEFAULT NULL COMMENT 'Отзыв',
  `visible` tinyint(4) DEFAULT NULL COMMENT 'Видимость',
  PRIMARY KEY (`id`),
  KEY `ixVisible` (`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_reviews` (`id`, `name`, `age`, `company`, `content`, `visible`) VALUES
(1,	'Иван',	27,	'Astana Creative',	'Молодцы ребята могёте!',	1),
(2,	'Готя Романовский',	25,	'ST Bar',	'Обратился в эту команду и меня поняли с первого слова. Буду еще к вам обращаться, так держать.',	1);

DROP TABLE IF EXISTS `iv_spares_category`;
CREATE TABLE `iv_spares_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL COMMENT 'Название',
  `description` mediumtext COMMENT 'Описание',
  `alias` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ixalias` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_spares_category` (`id`, `title`, `description`, `alias`) VALUES
(1,	'ПОГРУЗОЧНОЕ ОБОРУДОВАНИЕ',	'',	'pogruzochnoe-oborudovanie'),
(2,	'Двигатель',	'',	'dvigatel'),
(3,	'РОМ',	'',	'rom'),
(4,	'ГМП',	'',	'gmp'),
(5,	'Гидравлика',	'',	'gidravlika'),
(6,	'Карданные валы, мосты, колеса',	'',	'kardannie-vali-mosti-kolesa'),
(7,	'Фильтры',	'',	'filtri');

DROP TABLE IF EXISTS `iv_spares_item`;
CREATE TABLE `iv_spares_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `categoryId` int(11) unsigned DEFAULT NULL COMMENT 'Категория',
  `title` varchar(128) DEFAULT NULL COMMENT 'Товар',
  `model` varchar(128) DEFAULT NULL COMMENT 'Модель',
  `price` varchar(32) DEFAULT NULL COMMENT 'Цена',
  `productId` int(10) unsigned DEFAULT NULL COMMENT 'Id товара',
  PRIMARY KEY (`id`),
  KEY `ixCategoryId` (`categoryId`),
  KEY `ixProductId` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_spares_item` (`id`, `categoryId`, `title`, `model`, `price`, `productId`) VALUES
(5,	1,	'ВТУЛКИ',	'Втулка ТО-45 03.00.2004',	'4.500 тенге',	4),
(6,	1,	'ВТУЛКИ',	'Втулка ТО-45 03.00.2003',	'4.300 тенге',	4),
(9,	1,	'ВТУЛКИ',	'Втулка ТО-45 03.00.2004',	'4.500 тенге',	1),
(10,	1,	'ВТУЛКИ',	'Втулка ТО-45 03.00.2003',	'4.300 тенге',	1),
(11,	1,	'КОРОМЫСЛО',	'Коромысло ТО-45 03.00.2004',	'4.500 тенге',	1),
(12,	1,	'КОРОМЫСЛО',	'Коромысло ТО-45 03.00.2003',	'4.300 тенге',	1),
(13,	5,	'Гидробак',	'Гидробак, ТО-18Б.76.01.000-01',	'54 000 руб.',	1),
(14,	5,	'Гидроклапан',	'Гидроклапан, У 462.815.1',	'6 000 руб.',	1),
(15,	5,	'Гидроклапан',	'Гидроклапан, КО-20/2Т-00 04 (9 КОТ16/3ТК) обратный',	'5 000 руб.',	1),
(16,	5,	'Гидроклапан',	'Гидроклапан, КГ-6/Т2П',	'4 800 руб.',	1);

DROP TABLE IF EXISTS `iv_store_basket`;
CREATE TABLE `iv_store_basket` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `productId` int(11) unsigned DEFAULT NULL COMMENT 'Товар',
  `quantity` int(11) unsigned DEFAULT NULL COMMENT 'Кол-во',
  `dataCreate` datetime DEFAULT NULL COMMENT 'Дата и время добавления',
  `sessionId` varchar(64) DEFAULT NULL COMMENT 'Айди корзины',
  `type` tinyint(4) DEFAULT NULL COMMENT 'Тип (Корзина, заказ)',
  `position` int(11) DEFAULT NULL COMMENT 'Позиция в корзине',
  PRIMARY KEY (`id`),
  KEY `ixProductId` (`productId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `iv_store_category`;
CREATE TABLE `iv_store_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Название',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `visible` tinyint(4) DEFAULT NULL COMMENT 'Видимость',
  `position` int(11) DEFAULT NULL COMMENT 'Позивия',
  `modificatorTitle` varchar(128) DEFAULT NULL COMMENT 'Заголовок для модификаторов',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`),
  KEY `ixPosition` (`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_store_category` (`id`, `title`, `alias`, `visible`, `position`, `modificatorTitle`) VALUES
(1,	'Погрузчики универсальные',	'pogruzchiki-universalnie',	1,	1,	'БЫСТРОСМЕННЫЕ РАБОЧИЕ ОРГАНЫ'),
(2,	'Погрузчики фронтальные одноковшовые ',	'pogruzchiki-frontalnie-odnokovshovie',	1,	2,	'СМЕННЫЕ РАБОЧИЕ ОРГАНЫ'),
(10,	'Экскаваторы-погрузчики  на собственном шасси',	'exkavatori-pogruzchiki-na-sobstvennom-shassi',	1,	3,	'Сменные рабочие органы'),
(11,	'Экскаваторы  на собственном шасси',	'exkavatori-na-sobstvennom-shassi',	1,	4,	'Сменные рабочие органы'),
(12,	'Машины на базе тракторов мтз',	'mashini-na-baze-traktorov-mtz',	1,	5,	'Сменные рабочие органы'),
(13,	'Вилочные погрузчики',	'vilochnie-pogruzchiki',	1,	6,	''),
(14,	'Катки дорожные',	'katki-dorozhnie',	1,	7,	''),
(15,	'Техника снегоочистительная',	'tehnika-snegoochistitelnaya',	1,	8,	''),
(16,	'Зерноочистительные комплексы',	'zernoochistitelnie-komplexi',	1,	9,	'');

DROP TABLE IF EXISTS `iv_store_manufacturer`;
CREATE TABLE `iv_store_manufacturer` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Название',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `visible` tinyint(4) DEFAULT NULL COMMENT 'Видимость',
  `position` int(11) DEFAULT NULL COMMENT 'Позиция',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`),
  KEY `ixPosition` (`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `iv_store_order`;
CREATE TABLE `iv_store_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fio` varchar(128) DEFAULT NULL COMMENT 'ФИО',
  `phone` varchar(23) DEFAULT NULL COMMENT 'Телефон',
  `email` varchar(64) DEFAULT NULL COMMENT 'Email',
  `dateCreate` datetime DEFAULT NULL COMMENT 'Дата и время',
  `statusId` tinyint(4) DEFAULT NULL COMMENT 'Статус',
  `secretKey` varchar(32) DEFAULT NULL COMMENT 'Доступ',
  PRIMARY KEY (`id`),
  KEY `ixStatusId` (`statusId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `iv_store_order_item`;
CREATE TABLE `iv_store_order_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `orderId` int(11) unsigned DEFAULT NULL COMMENT 'Заказ',
  `productId` int(11) unsigned DEFAULT NULL COMMENT 'Товар',
  `quantity` int(11) DEFAULT NULL COMMENT 'Кол-во',
  PRIMARY KEY (`id`),
  KEY `ixProductId` (`productId`),
  KEY `ixOrderId` (`orderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `iv_store_product`;
CREATE TABLE `iv_store_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Название',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `categoryId` int(11) unsigned NOT NULL COMMENT 'Категория',
  `manufacturerId` int(11) NOT NULL COMMENT 'Производитель',
  `content` mediumtext COMMENT 'Описание',
  `minCount` int(10) unsigned DEFAULT '0' COMMENT 'Минимальный заказ',
  `quantity` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Кол-во на складе',
  `visible` tinyint(4) DEFAULT '0' COMMENT 'Видимость',
  PRIMARY KEY (`id`),
  KEY `ixCategoryId` (`categoryId`),
  KEY `ixManufacturerId` (`manufacturerId`),
  KEY `ixAlias` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_store_product` (`id`, `title`, `alias`, `categoryId`, `manufacturerId`, `content`, `minCount`, `quantity`, `visible`) VALUES
(1,	'АМКОДОР 320, АМКОДОР 320Е',	'amkodor-320-amkodor-320e',	1,	0,	'<h3>ОБЗОР СЕРИИ</h3><p>Погрузчики универсальные АМКОДОР 320 и АМКОДОР 320Е – компактные многоцелевые машины, предназначенные для использования в строительстве, в коммунальном и сельском хозяйстве, в морских и речных портах, на складах, где требуется маневренность в стесненных условиях.</p><p>АМКОДОР 320Е оснащен дизелем фирмы Deutz (Германия) экологического класса Stage IIIA и незаменим в коммунальном хозяйстве мегаполисов, где предъявляются повышенные требования к экологии.</p><p>На машинах установлена гидрообъемная трансмиссия фирмы Sauer-Danfoss (Дания) с электронным управлением, ведущие мосты фирм Carraro (Италия) или Dana (Италия) с самоблокирующимися дифференциалами повышенного трения и многодисковыми тормозами в «масле», что обеспечивает бесступенчатое изменение скорости движения, плавность хода и высокую проходимость. В сочетании с шарнирно-сочлененной рамой с углом складывания ±40° и просторной кабиной с хорошей обзорностью это обеспечивает эффективную работу в стесненных условиях.</p><p>Механическое устройство для быстрой смены рабочих органов позволяет произвести их замену в течение 2-3 минут. Оператору необходимо выйти из кабины только для установки фиксирующих пальцев и подсоединения нескольких быстроразъемных гидравлических муфт.</p><p>В базовом исполнении погрузчики оснащены ковшом, все остальные быстросменные рабочие органы заказываются дополнительно. По желанию заказчика возможна адаптация рабочих органов специализированных фирм-изготовителей.</p><div><table><thead><tr><th><div> </div></th><th><div><strong>АМКОДОР 320</strong></div></th><th><div><strong>АМКОДОР 320Е</strong></div></th></tr></thead><tbody><tr><td><div>Грузоподъемность, кг</div></td><td colspan=\"2\"><div>2000</div></td></tr><tr><td><div>Устройство для быстрой смены рабочих органов</div></td><td colspan=\"2\"><div>Механическое</div></td></tr><tr><td><div>Обозначение основного ковша</div></td><td colspan=\"2\"><div>320.45.01.000-В</div></td></tr><tr><td><div>Вместимость ковша номинальная, м<sup>3</sup></div></td><td colspan=\"2\"><div>1.1</div></td></tr><tr><td><div>Ширина режущей кромки ковша, мм</div></td><td colspan=\"2\"><div>2100</div></td></tr><tr><td><div>Высота разгрузки, мм</div></td><td colspan=\"2\"><div>2600</div></td></tr><tr><td><div>Вылет кромки ковша, мм</div></td><td colspan=\"2\"><div>880</div></td></tr><tr><td><div>Радиус поворота по наружной кромке ковша в транспортном положении, мм</div></td><td colspan=\"2\"><div>4800</div></td></tr><tr><td><div>Вырывное усилие, кН</div></td><td colspan=\"2\"><div>40</div></td></tr><tr><td><div>Статическая опрокидывающая нагрузка в сложенном (±40°) положении, кН</div></td><td colspan=\"2\"><div>40</div></td></tr><tr><td><div>Масса эксплуатационная, кг</div></td><td colspan=\"2\"><div>6350</div></td></tr><tr><td><div>Дизель</div></td><td><div>Д-245.43S2</div><div> </div></td><td><div>Deutz TD 2012 L04 2Vm</div></td></tr><tr><td><div>Мощность номинальная</div></td><td><div>62 кВт (84 л.с.)</div><div>при 1800 об/мин</div></td><td><div>60 кВт (82 л.с.)</div><div>при 2000 об/мин</div></td></tr><tr><td><div>Трансмиссия</div></td><td colspan=\"2\"><div>Гидрообьемная, замкнутая,</div><div>с регулируемыми насосом и гидромотором,</div><div>с электронной системой управления</div></td></tr><tr><td><div>Скорость передвижения, вперед/назад, км/ч:</div><div>-рабочая</div><div>-транспортная</div></td><td><div> </div><div> </div><div>0 – 7.8/0-7.8</div><div>0 – 29/0-29</div></td><td><div> </div><div> </div><div>0 – 6.5/0-6.5</div><div> 0 – 20/0-20</div></td></tr><tr><td><div>Угол качания заднего моста, град</div></td><td colspan=\"2\"><div>±8</div></td></tr><tr><td><div>Дифференциал</div></td><td colspan=\"2\"><div>Самоблокирующийся повышенного трения</div></td></tr><tr><td><div>Рабочая тормозная система</div></td><td colspan=\"2\"><div>Многодисковые тормозные механизмы в «масле» переднего моста (DANA) или заднего моста (CARRARO) с гидростатическим приводом и дополнительное торможением замкнутым контуром гидрообъемной трансмиссии</div></td></tr><tr><td><div>Стояночная и аварийная тормозные системы</div></td><td colspan=\"2\"><div>Однодисковый тормозной механизм c механическим управлением</div></td></tr><tr><td><div>Рулевое управление</div></td><td colspan=\"2\"><div>Шарнирно-сочлененная рама,</div><div>с гидравлическим приводом и гидравлической обратной связью</div></td></tr><tr><td><div>Шины</div></td><td colspan=\"2\"><div>16.0-20</div></td></tr><tr><td><div>Тип гидросистемы погрузочного оборудования и рулевого управления</div></td><td colspan=\"2\"><div>Двухнасосная, с одним насосом погрузочного оборудования и отдельным насосом рулевого управления</div></td></tr><tr><td><div>Тип гидрораспределителя</div></td><td colspan=\"2\"><div>3-секционный с прямым механическим управлением</div></td></tr><tr><td><div>Время гидравлического цикла, с:</div><div>-подъем</div><div>-разгрузка</div><div>-опускание</div></td><td colspan=\"2\"><div> </div><div>4.5</div><div>1.6</div><div>3.4</div></td></tr><tr><td><div>Длина, в транспортном положении с основным ковшом, мм</div></td><td colspan=\"2\"><div>6000</div></td></tr><tr><td><div>Ширина по ковшу, мм</div></td><td colspan=\"2\"><div>2100</div></td></tr><tr><td><div>Ширина по колёсам, мм</div></td><td colspan=\"2\"><div>2000</div></td></tr><tr><td><div>Высота по крыше кабины, мм</div></td><td colspan=\"2\"><div>2800</div></td></tr></tbody></table><img alt=\"\" src=\"http://amkodor.by/uploads/userfiles/images/navesnoe/320e_2.jpg\"></div><div> </div><div><strong>Погрузочные машины</strong> производства холдинга «<em>АМКОДОР</em>» отличаются своей надежностью, высокими технологическими характеристиками и удобным использованием. Все модели современных погрузчиков имеют кабины с повышенной обзорностью, шумоизоляцией и обеспечивают комфортные условия работы.</div><div>Для поддержания комфортной температуры в зимнее время, <strong>дизельный погрузчик</strong> оснащен салонным обогревателем. Для изготовления элементов интерьера в холдинге используется качественный материал ABS.</div><div>Выбор марки погрузчика напрямую зависит от предстоящих работ и условий эксплуатации.</div><div>С функциями горизонтального транспортирования и погрузочными работами прекрасно справляются <strong>автопогрузчики дизельные</strong> «<em>АМКОДОР</em>». Они способны обеспечить очень высокую отдачу эксплуатации на складах. Использование дизельного топлива делает эту технику вредной для людей при работе внутри помещения. Поэтому автопогрузчики, работающие на дизельном топливе, применяются только на открытом воздухе. Для решения этой проблемы<strong>производители дорожной техники</strong> предлагают специальные нейтрализаторы, которые снижают интенсивность выхлопных газов.</div><div>Важная часть погрузочной техники – возможность замены рабочих органов. Наличие дополнительного навесного оборудования значительно расширяет сферу ее применения. Универсальные погрузчики используются как<strong>коммунальная дорожная техника</strong>, и в других отраслях народного хозяйства, в дорожном, производственном и гражданском строительстве.</div>',	0,	0,	1),
(2,	'АМКОДОР 320СЕ',	'amkodor-320se',	1,	0,	'<h3>ОБЗОР СЕРИИ</h3><div><div><p>Погрузчик универсальный АМКОДОР 320СЕ – многоцелевая машина компактного класса и предназначена для использования в строительстве, в коммунальном и сельском хозяйстве, в морских и речных портах, на складах, где требуется эффективная работа в ограниченном пространстве.</p><p>АМКОДОР 320СЕ оснащен дизелем фирмы Deutz (Германия) экологического класса Stage IIIA, что особенно важно при работе в коммунальном хозяйстве мегаполисов, где предъявляются повышенные требования к экологии.</p><p>На машинах установлена гидрообъемная трансмиссия фирмы Sauer-Danfoss (Дания) с электронным управлением, ведущие мосты фирм Carraro (Италия) или Dana (Италия) с самоблокирующимися дифференциалами повышенного трения и многодисковыми тормозами в «масле», что обеспечивает бесступенчатое изменение скорости движения, плавность хода и высокую проходимость. В сочетании с шарнирно-сочлененной рамой с углом складывания ±40°, удобной и комфортабельной кабиной с хорошей обзорностью это обеспечивает эффективную работу в стесненных условиях.</p><p>Гидравлическое устройство для быстрой смены рабочих органов погрузчика позволяет произвести замену рабочих органов в течение 1-2 минут без выхода оператора из кабины. При установке активных рабочих органов необходимо дополнительно подсоединить несколько быстроразъемных муфт для соединения гидравлических трубопроводов.</p><p>Для управления рабочим оборудованием в кабине установлено два гидравлических джойстика. Один - универсальный, который управляет стрелой и ковшом, имеет переключатель реверса движения машины и две электрические кнопки для управления 3-й гидравлической функцией. Второй джойстик - 3-позиционный с фиксацией для 4-й гидравлической функции, например, для привода щётки и других активных быстросменных рабочих органов, которым необходимы 2 гидравлические функции. Это позволяет адаптировать рабочие органы специализированных фирм-изготовителей.</p><p>В базовом исполнении погрузчик оснащен ковшом, все остальные быстросменные рабочие органы заказываются дополнительно.</p><p>Погрузчик оснащён комфортабельной кабиной, в базовую комплектацию которой входит кондиционер-отопитель, регулируемая рулевая колонка и сиденье, переключатель 12/24В, гнездо для подключения мобильного телефона и МР3 плейера.</p></div></div><div><table><thead><tr><th><div> </div></th><th><div><strong>АМКОДОР 320СЕ</strong></div></th></tr></thead><tbody><tr><td><div>Грузоподъемность, кг</div></td><td><div>2000</div></td></tr><tr><td><div>Устройство для быстрой смены рабочих органов</div></td><td><div>Гидравлическое</div></td></tr><tr><td><div>Обозначение основного ковша</div></td><td><div>320СЕ.45.01.000</div></td></tr><tr><td><div>Вместимость ковша номинальная , м<sup>3</sup></div></td><td><div>1.1</div></td></tr><tr><td><div>Ширина режущей кромки ковша, мм</div></td><td><div>2100</div></td></tr><tr><td><div>Высота разгрузки, мм</div></td><td><div>2700</div></td></tr><tr><td><div>Вылет кромки ковша, мм</div></td><td><div>710</div></td></tr><tr><td><div>Радиус поворота по наружной кромке ковша в транспортном положении, мм</div></td><td><div>4800</div></td></tr><tr><td><div>Вырывное усилие, кН</div></td><td><div>40</div></td></tr><tr><td><div>Статическая опрокидывающая нагрузка в сложенном (±40°) положении, кН</div></td><td><div>40</div></td></tr><tr><td><div>Масса эксплуатационная, кг</div></td><td><div>6200</div></td></tr><tr><td><div>Дизель</div></td><td><div>Deutz TD 2012 L04 2Vm</div></td></tr><tr><td><div>Мощность номинальная</div></td><td><div>60 кВт (82 л.с.) при 2000 об/мин</div></td></tr><tr><td><div>Трансмиссия</div></td><td><div>Гидрообьемная, замкнутая,</div><div>с регулируемыми насосом и гидромотором,</div><div>с электронной системой управления</div></td></tr><tr><td><div>Скорость передвижения, вперед/назад, км/ч:</div><div>-рабочая</div><div>-транспортная</div></td><td><div> </div><div> </div><div>0 – 7/0-7</div><div>0 – 20/0-20</div></td></tr><tr><td><div>Угол качания заднего моста, град</div></td><td><div>±8</div></td></tr><tr><td><div>Дифференциал</div></td><td><div>Самоблокирующийся повышенного трения</div></td></tr><tr><td><div>Рабочая тормозная система</div></td><td><div>Многодисковые тормозные механизмы в «масле» переднего моста (DANA) или заднего моста (CARRARO) с гидростатическим приводом и дополнительное торможением замкнутым контуром гидрообъемной трансмиссии</div></td></tr><tr><td><div>Стояночная и аварийная тормозные системы</div></td><td><div>Однодисковый тормозной механизм c механическим управлением</div></td></tr><tr><td><div>Рулевое управление</div></td><td><div>Шарнирно-сочлененная рама,</div><div>с гидравлическим приводом и гидравлической обратной связью</div></td></tr><tr><td><div>Шины</div></td><td><div>16.0-20</div></td></tr><tr><td><div>Тип гидросистемы погрузочного оборудования и рулевого управления</div></td><td><div>Двухнасосная, с одним насосом погрузочного оборудования и отдельным насосом рулевого управления</div></td></tr><tr><td><div>Тип гидрораспределителя</div></td><td><div>4-секционный с прямым гидравлическим управлением</div></td></tr><tr><td><div>Время гидравлического цикла, с:</div><div>-подъем</div><div>-разгрузка</div><div>-опускание</div></td><td><div> </div><div>4</div><div>1.2</div><div>2.6</div></td></tr><tr><td><div>Длина, в транспортном положении с основным ковшом, мм</div></td><td><div>5910</div></td></tr><tr><td><div>Ширина по ковшу, мм</div></td><td><div>2100</div></td></tr><tr><td><div>Ширина по колёсам, мм</div></td><td><div>2000</div></td></tr><tr><td><div>Высота по крыше кабины, мм</div></td><td><div>2800</div></td></tr></tbody></table></div><div> </div><div><img alt=\"\" src=\"http://amkodor.by/uploads/userfiles/images/navesnoe/320ce.jpg\"></div><div><strong>Погрузочные машины</strong> производства холдинга «<em>АМКОДОР</em>» отличаются своей надежностью, высокими технологическими характеристиками и удобным использованием. Все модели современных погрузчиков имеют кабины с повышенной обзорностью, шумоизоляцией и обеспечивают комфортные условия работы.</div><div>Для поддержания комфортной температуры в зимнее время, <strong>дизельный погрузчик</strong> оснащен салонным обогревателем. Для изготовления элементов интерьера в холдинге используется качественный материал ABS.</div><div>Выбор марки погрузчика напрямую зависит от предстоящих работ и условий эксплуатации.</div><div>С функциями горизонтального транспортирования и погрузочными работами прекрасно справляются <strong>автопогрузчики дизельные</strong> «<em>АМКОДОР</em>». Они способны обеспечить очень высокую отдачу эксплуатации на складах. Использование дизельного топлива делает эту технику вредной для людей при работе внутри помещения. Поэтому автопогрузчики, работающие на дизельном топливе, применяются только на открытом воздухе. Для решения этой проблемы<strong>производители дорожной техники</strong> предлагают специальные нейтрализаторы, которые снижают интенсивность выхлопных газов.</div><div>Важная часть погрузочной техники – возможность замены рабочих органов. Наличие дополнительного навесного оборудования значительно расширяет сферу ее применения. Универсальные погрузчики используются как<strong>коммунальная дорожная техника</strong>, и в других отраслях народного хозяйства, в дорожном, производственном и гражданском строительстве.</div>',	0,	0,	1),
(3,	'АМКОДОР 325С, АМКОДОР 325С-01',	'amkodor-325s-amkodor-325s-01',	1,	0,	'<p>Погрузчики универсальные АМКОДОР 325С и АМКОДОР 325С-01 – многоцелевые машины малого класса, предназначенные для использования в строительстве, в коммунальном и сельском хозяйстве, в морских и речных портах, на складах, где требуется маневренность в ограниченном пространстве.</p><p>На машинах установлены гидромеханическая передача и ведущие мосты с самоблокирующимися дифференциалами повышенного трения и многодисковыми тормозами в «масле», которые в комбинации с дизельным двигателем мощностью 77 кВт обеспечивают высокие тягово-динамические показатели и высокую проходимость. В сочетании с шарнирно-сочлененной рамой с углом складывания ±38° и просторной кабиной с хорошей обзорностью обеспечивают эффективную работу в условиях ограниченного пространства.</p><p>Гидравлическое устройство для быстрой смены рабочих органов погрузчика АМКОДОР 325С-01 позволяет произвести замену рабочих органов в течение 1-2 минут без выхода оператора из кабины. При установке активных рабочих органов необходимо дополнительно подсоединить несколько быстроразъемных муфт для соединения гидравлических трубопроводов.</p><p>На погрузчике АМКОДОР 325С используется механическое устройство для быстрой смены рабочих органов, поэтому необходим выход оператора из кабины для установки фиксирующих пальцев. Время замены составляет 2-3 минуты.</p><p>В базовом исполнении погрузчики оснащены ковшом, все остальные быстросменные рабочие органы заказываются дополнительно.</p><table><thead><tr><th><div> </div></th><th><div><strong>АМКОДОР 325С</strong></div></th><th><div><strong>АМКОДОР 325С-01</strong></div></th></tr></thead><tbody><tr><td><div>Грузоподъемность, кг</div></td><td colspan=\"3\"><div>2600</div></td></tr><tr><td><div>Устройство для быстрой смены рабочих органов</div></td><td><div>Механическое</div></td><td colspan=\"2\"><div>Гидравлическое</div></td></tr><tr><td><div>Номер основного ковша</div></td><td><div>325С.45.01.010</div></td><td colspan=\"2\"><div>325С.51.00.000</div></td></tr><tr><td><div>Вместимость ковша номинальная, м<sup>3</sup></div></td><td colspan=\"3\"><div>1.4</div></td></tr><tr><td><div>Ширина режущей кромки ковша, мм</div></td><td colspan=\"3\"><div>2500</div></td></tr><tr><td><div>Высота разгрузки, мм</div></td><td><div>2600</div></td><td colspan=\"2\"><div>2650</div></td></tr><tr><td><div>Вылет кромки ковша, мм</div></td><td><div>950</div></td><td colspan=\"2\"><div>900</div></td></tr><tr><td><div>Радиус поворота, мм</div></td><td colspan=\"3\"><div>5800</div></td></tr><tr><td><div>Вырывное усилие, кН</div></td><td colspan=\"3\"><div>60</div></td></tr><tr><td><div>Статическая опрокидывающая нагрузка</div><div>в сложенном (±38°) положении, кН</div></td><td colspan=\"3\"><div> </div><div>52</div></td></tr><tr><td><div>Масса эксплуатационная, кг</div></td><td colspan=\"3\"><div>8800</div></td></tr><tr><td><div>Дизель</div></td><td colspan=\"3\"><div>Д-245</div></td></tr><tr><td><div>Мощность номинальная</div></td><td colspan=\"3\"><div>77 кВт (105 л.с.) при 2200 об/мин</div></td></tr><tr><td><div>Трансмиссия</div></td><td colspan=\"3\"><div>Гидромеханическая</div></td></tr><tr><td><div>Скорость передвижения, вперед/назад, км/ч:</div><div>1-я</div><div>4-я</div></td><td colspan=\"3\"><div> </div><div> </div><div>5.8/5.9</div><div>32/--</div></td></tr><tr><td><div>Угол качания заднего моста, град</div></td><td colspan=\"3\"><div>±12</div></td></tr><tr><td><div>Дифференциал</div></td><td colspan=\"3\"><div>Повышенного трения</div></td></tr><tr><td><div>Рабочая тормозная система</div></td><td colspan=\"3\"><div>Многодисковые тормозные механизмы в «масле», с раздельным гидравлическим приводом по мостам</div></td></tr><tr><td><div>Стояночная и аварийная тормозные системы</div></td><td colspan=\"3\"><div>Однодисковый сухой тормозной механизм, с пружинным сжатием и гидравлическим растормаживанием</div></td></tr><tr><td><div>Рулевое управление</div></td><td colspan=\"3\"><div>Шарнирно-сочлененная рама, с гидравлическим приводом и гидравлической обратной связью, аварийным насосом с приводом от ведущих колес</div></td></tr><tr><td><div>Шины</div></td><td colspan=\"3\"><div>21.3-24</div></td></tr><tr><td><div>Тип гидросистемы</div></td><td colspan=\"3\"><div>Двухнасосная с приоритетным клапаном для рулевого управления</div></td></tr><tr><td><div>Тип гидрораспределителя</div></td><td colspan=\"3\"><div>3-секционный с прямым гидравлическим управлением</div><div> </div></td></tr><tr><td><div>Время гидравлического цикла, с:</div><div>подъем</div><div>разгрузка</div><div>опускание</div></td><td colspan=\"3\"><div> </div><div> </div><div>3.9</div><div>1.2</div><div>3.0</div></td></tr><tr><td><div>Длина, в транспортном положении с основным ковшом, мм</div></td><td colspan=\"3\"><div>6500</div></td></tr><tr><td><div>Ширина по ковшу, мм</div></td><td colspan=\"3\"><div>2500</div></td></tr><tr><td><div>Ширина по колесам, мм</div></td><td colspan=\"3\"><div>2410</div></td></tr><tr><td><div>Высота по крыше кабины, мм</div></td><td colspan=\"3\"><div>3370</div></td></tr></tbody></table><div>АМКОДОР 325С</div><p><br><img alt=\"\" src=\"http://amkodor.by/uploads/userfiles/images/navesnoe/325c(2).jpg\"></p><p>АМКОДОР 325С-01</p><p><br><img alt=\"\" src=\"http://amkodor.by/uploads/userfiles/images/navesnoe/325c01.jpg\"></p><div><strong>Погрузочные машины</strong> производства холдинга «<em>АМКОДОР</em>» отличаются своей надежностью, высокими технологическими характеристиками и удобным использованием. Все модели современных погрузчиков имеют кабины с повышенной обзорностью, шумоизоляцией и обеспечивают комфортные условия работы.</div><div>Для поддержания комфортной температуры в зимнее время, <strong>дизельный погрузчик</strong> оснащен салонным обогревателем. Для изготовления элементов интерьера в холдинге используется качественный материал ABS.</div><div>Выбор марки погрузчика напрямую зависит от предстоящих работ и условий эксплуатации.</div><div>С функциями горизонтального транспортирования и погрузочными работами прекрасно справляются <strong>автопогрузчики дизельные</strong> «<em>АМКОДОР</em>». Они способны обеспечить очень высокую отдачу эксплуатации на складах. Использование дизельного топлива делает эту технику вредной для людей при работе внутри помещения. Поэтому автопогрузчики, работающие на дизельном топливе, применяются только на открытом воздухе. Для решения этой проблемы <strong>производители дорожной техники</strong> предлагают специальные нейтрализаторы, которые снижают интенсивность выхлопных газов.</div><div>Важная часть погрузочной техники – возможность замены рабочих органов. Наличие дополнительного навесного оборудования значительно расширяет сферу ее применения. Универсальные погрузчики используются как <strong>коммунальная дорожная техника</strong>, и в других отраслях народного хозяйства, в дорожном, производственном и гражданском строительстве.</div>',	0,	0,	1),
(4,	'АМКОДОР 330СЕ',	'amkodor-330se',	1,	0,	'<h3>ОБЗОР СЕРИИ</h3><div>\r\n	<p>Погрузчик универсальный АМКОДОР 330СЕ – многоцелевая машина среднего класса и предназначена для использования в строительстве, в коммунальном и сельском хозяйстве, в морских и речных портах, на складах, где требуется эффективная работа в ограниченном пространстве.\r\n	</p>\r\n	<p>АМКОДОР 330СЕ оснащен дизелем фирмы Deutz (Германия) экологического класса Stage IIIA, что особенно важно при работе в коммунальном хозяйстве мегаполисов, где предъявляются повышенные требования к экологии.\r\n	</p>\r\n	<p>На машинах установлена гидромеханическая трансмиссия фирмы Carraro (Италия) с электронным управлением, ведущие мосты фирмы Carraro (Италия) или производства холдинга «АМКОДОР» с самоблокирующимися дифференциалами повышенного трения и многодисковыми тормозами в «масле».\r\n	</p>\r\n	<p>Гидравлическое устройство для быстрой смены рабочих органов погрузчика позволяет произвести замену рабочих органов в течение 1-2 минут без выхода оператора из кабины. При установке активных рабочих органов необходимо дополнительно подсоединить несколько быстроразъемных муфт для соединения гидравлических трубопроводов.\r\n	</p>\r\n	<p>Для управления рабочим оборудованием в кабине установлено два гидравлических джойстика. Один - универсальный, который управляет стрелой и ковшом, имеет переключатель реверса движения машины и две электрические кнопки для управления 3-й гидравлической функцией. Второй джойстик - 3-позиционный с фиксацией для 4-й гидравлической функции, например, для привода щётки и других активных быстросменных рабочих органов, которым необходимы 2 гидравлические функции. Это позволяет адаптировать рабочие органы специализированных фирм-изготовителей.\r\n	</p>\r\n	<p>В базовом исполнении погрузчик оснащен ковшом, все остальные быстросменные рабочие органы заказываются дополнительно.\r\n	</p>\r\n	<p>Погрузчик оснащён комфортабельной кабиной, в базовую комплектацию которой входит кондиционер-отопитель, регулируемая рулевая колонка и сиденье, переключатель 12/24В, гнездо для подключения мобильного телефона и МР3 плейера.\r\n	</p>\r\n</div><div>\r\n	<table>\r\n	<thead>\r\n	<tr>\r\n		<th>\r\n			<div>\r\n			</div>\r\n		</th>\r\n		<th>\r\n			<div><strong>АМКОДОР 330СЕ</strong>\r\n			</div>\r\n		</th>\r\n	</tr>\r\n	</thead>\r\n	<tbody>\r\n	<tr>\r\n		<td>\r\n			<div>Грузоподъемность, кг\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>3000\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Устройство для быстрой смены рабочих органов\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>Гидравлическое\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Номер основного ковша\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>330СЕ.45.01.000\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Вместимость ковша номинальная, м<sup>3</sup>\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>1.65\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Ширина режущей кромки ковша, мм\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>2500\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Высота разгрузки, мм\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>2800\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Вылет кромки ковша, мм\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>880\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Радиус поворота, мм\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>5500\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Вырывное усилие, кН\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>82\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Статическая опрокидывающая нагрузка\r\n			</div>\r\n			<div>в сложенном (±40°) положении, кН\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>60\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Масса эксплуатационная, мосты Carraro/15H, кг\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>8800/9200\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Дизель\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>Deutz ТСD 2012 L04 2V\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Мощность номинальная\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>91 кВт (124 л.с.) при 2200 об/мин\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Трансмиссия\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>Гидромеханическая\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Скорость передвижения, вперед/назад, км/ч:\r\n			</div>\r\n			<div>1-я\r\n			</div>\r\n			<div>2-я\r\n			</div>\r\n			<div>3-я\r\n			</div>\r\n			<div>4-я\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>\r\n			</div>\r\n			<div>\r\n			</div>\r\n			<div>5.5/5/5\r\n			</div>\r\n			<div>9.4/9.4\r\n			</div>\r\n			<div>20.5/20.5\r\n			</div>\r\n			<div>34/34\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Мосты ведущие\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>Carraro или 15H\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Угол качания заднего моста, град\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>±12\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Дифференциал\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>Повышенного трения\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Рабочая тормозная система\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>Многодисковые тормозные механизмы в «масле», с раздельным гидравлическим приводом по мостам\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Стояночная и аварийная тормозные системы\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>Однодисковый сухой тормозной механизм, с пружинным сжатием и гидравлическим растормаживанием\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Рулевое управление\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>Шарнирно-сочлененная рама, с гидравлическим приводом и гидравлической обратной связью, аварийным насосом с приводом от ведущих колес\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Шины\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>20.0/60-22.5L-2\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Тип гидросистемы\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>Двухнасосная с приоритетным клапаном для рулевого управления\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Тип гидрораспределителя\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>4-секционный с прямым гидравлическим управлением\r\n			</div>\r\n			<div>\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Время гидравлического цикла, с:\r\n			</div>\r\n			<div>подъем\r\n			</div>\r\n			<div>разгрузка\r\n			</div>\r\n			<div>опускание\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>\r\n			</div>\r\n			<div>5.4\r\n			</div>\r\n			<div>1\r\n			</div>\r\n			<div>3.6\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Длина, в транспортном положении с основным ковшом, мм\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>6850\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Ширина по ковшу, мм\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>2500\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Ширина по колесам, мм\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>2350\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<div>Высота по крыше кабины, мм\r\n			</div>\r\n		</td>\r\n		<td>\r\n			<div>3150\r\n			</div>\r\n		</td>\r\n	</tr>\r\n	</tbody>\r\n	</table><img alt=\"\" src=\"http://amkodor.by/uploads/userfiles/images/navesnoe/330ce_1.jpg\">\r\n</div><div><strong>Погрузочные машины</strong> производства холдинга «<em>АМКОДОР</em>» отличаются своей надежностью, высокими технологическими характеристиками и удобным использованием. Все модели современных погрузчиков имеют кабины с повышенной обзорностью, шумоизоляцией и обеспечивают комфортные условия работы.\r\n</div><div>Для поддержания комфортной температуры в зимнее время, <strong>дизельный погрузчик</strong> оснащен салонным обогревателем. Для изготовления элементов интерьера в холдинге используется качественный материал ABS.\r\n</div><div>Выбор марки погрузчика напрямую зависит от предстоящих работ и условий эксплуатации.\r\n</div><div>С функциями горизонтального транспортирования и погрузочными работами прекрасно справляются <strong>автопогрузчики дизельные</strong> «<em>АМКОДОР</em>». Они способны обеспечить очень высокую отдачу эксплуатации на складах. Использование дизельного топлива делает эту технику вредной для людей при работе внутри помещения. Поэтому автопогрузчики, работающие на дизельном топливе, применяются только на открытом воздухе. Для решения этой проблемы<strong>производители дорожной техники</strong> предлагают специальные нейтрализаторы, которые снижают интенсивность выхлопных газов.\r\n</div><div>Важная часть погрузочной техники – возможность замены рабочих органов. Наличие дополнительного навесного оборудования значительно расширяет сферу ее применения. Универсальные погрузчики используются как<strong>коммунальная дорожная техника</strong>, и в других отраслях народного хозяйства, в дорожном, производственном и гражданском строительстве.\r\n</div>',	0,	0,	1);

DROP TABLE IF EXISTS `iv_user`;
CREATE TABLE `iv_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `auth_key` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `dateCreate` datetime DEFAULT NULL COMMENT 'Дата регистрации',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user` (`id`, `username`, `password`, `auth_key`, `password_reset_token`, `dateCreate`) VALUES
(1,	'admin',	'$2y$13$ArLAzOtWEgnMbK2FEhsSa.NrcbCg9FXtaGvmAownBd4RVon5hEEOO',	'',	NULL,	NULL),
(2,	'manager',	'$2y$13$0RmhBJluvaJ5ImW6yzPQ0eGvppuQ3NzwirgjxWPNffGeKYWXOIWgW',	'\0s',	NULL,	NULL),
(33,	'vodyanov.ivan@yandex.ru',	'$2y$13$4U2Xasj0BbeF3Uu0t2nyrubmGONBluLR6TEXv2ukzCbSr31gtQ7nS',	'P',	NULL,	NULL),
(40,	'viadeveloper@gmail.com',	'$2y$13$Q5ZZ4E.9WtlK9lMlzrNpXOAtOv5JRd/9yW3VJ8k9vXJelUsfWeZ3K',	'\Z2',	NULL,	'2015-07-03 11:45:52'),
(41,	'x_vans_x@mail.ru',	'$2y$13$2TaZlTVBy6m0wTBCudFsDu8TYQEBsdbFmvmNRnmeqVzQ1To0ujXvK',	'',	NULL,	'2015-07-03 11:46:31');

DROP TABLE IF EXISTS `iv_user_balance_history`;
CREATE TABLE `iv_user_balance_history` (
  `id` varchar(255) NOT NULL,
  `userId` int(11) NOT NULL COMMENT 'Пользователь',
  `type` smallint(6) NOT NULL COMMENT 'Тип операции',
  `sum` decimal(20,2) NOT NULL COMMENT 'Сумма',
  `date` datetime NOT NULL COMMENT 'Дата и время',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user_balance_history` (`id`, `userId`, `type`, `sum`, `date`) VALUES
('b2330fc4531de135266de49078c270dd',	33,	1,	1000.00,	'2015-07-03 11:46:31'),
('c0c783b5fc0d7d808f1d14a6e9c8280d',	33,	1,	1000.00,	'2015-07-03 11:45:52'),
('d8e957bd2da1e36a73234faefd0547b3',	33,	2,	100.00,	'2015-07-03 11:51:51');

DROP TABLE IF EXISTS `iv_user_partner`;
CREATE TABLE `iv_user_partner` (
  `userId` int(11) NOT NULL COMMENT 'Пользователь',
  `partnerId` int(11) NOT NULL COMMENT 'Партнер',
  KEY `unique` (`userId`,`partnerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user_partner` (`userId`, `partnerId`) VALUES
(40,	33),
(41,	33);

DROP TABLE IF EXISTS `iv_user_profile`;
CREATE TABLE `iv_user_profile` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cityId` int(11) DEFAULT NULL,
  `photo` varchar(255) NOT NULL,
  `balance` decimal(20,2) DEFAULT '0.00' COMMENT 'Баланс',
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user_profile` (`userId`, `phone`, `name`, `cityId`, `photo`, `balance`) VALUES
(1,	'+998909124218',	'Водянов Иван',	2,	'',	0.00),
(33,	'+998712962849',	'Водянов Иван Александрович',	3,	'',	1900.00),
(40,	'+998712962849',	'Водянов Иван Александрович',	1,	'',	0.00),
(41,	'+998909124218',	'ViaDeveloper',	3,	'',	0.00);

DROP TABLE IF EXISTS `iv_user_pyramid`;
CREATE TABLE `iv_user_pyramid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `type` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ixParentId` (`parentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2015-09-06 07:41:42
